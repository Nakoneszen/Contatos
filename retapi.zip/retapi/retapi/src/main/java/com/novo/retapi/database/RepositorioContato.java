package com.novo.retapi.database;

import com.novo.retapi.entidade.Contato;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioContato extends JpaRepository< Contato, Long> {
    
}
